import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, PermissionsAndroid, Alert } from 'react-native';
import { SendDirectSms } from 'react-native-send-direct-sms';

const SmsScreen = () => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [bodySMS, setBodySMS] = useState('');

  const requestSmsPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.SEND_SMS,
        {
          title: 'Permissão para enviar SMS',
          message: 'Este aplicativo precisa de acesso para enviar mensagens SMS.',
          buttonNeutral: 'Pergunte-me depois',
          buttonNegative: 'Cancelar',
          buttonPositive: 'OK',
        },
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  const sendSMS = async () => {
    const hasPermission = await requestSmsPermission();
    if (hasPermission) {
      SendDirectSms(mobileNumber, bodySMS)
        .then((res) => {
          console.log('SMS enviado:', res);
          Alert.alert('Sucesso', 'SMS enviado com sucesso.');
        })
        .catch((err) => {
          console.log('Erro ao enviar SMS:', err);
          Alert.alert('Erro', 'Falha ao enviar SMS.');
        });
    } else {
      Alert.alert('Permissão negada', 'Não será possível enviar SMS.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enviar SMS</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Número de telefone"
        keyboardType="phone-pad"
        value={mobileNumber}
        onChangeText={setMobileNumber}
        placeholderTextColor="#aaa"
      />
      
      <TextInput
        style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
        placeholder="Mensagem"
        value={bodySMS}
        onChangeText={setBodySMS}
        multiline
        numberOfLines={4}
        placeholderTextColor="#aaa"
      />

      <TouchableOpacity style={styles.button} onPress={sendSMS}>
        <Text style={styles.buttonText}>Enviar SMS</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#f9f9f9',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 24,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    fontSize: 16,
    color: '#000',
  },
  button: {
    backgroundColor: '#FF5722',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});

export default SmsScreen;
