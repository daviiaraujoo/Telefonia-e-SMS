import React from 'react';
import { View, Text, TouchableOpacity, Alert, PermissionsAndroid, Linking, StyleSheet } from 'react-native';

const PhoneScreen = ({ navigation }) => {
  const makeCall = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CALL_PHONE,
        {
          title: 'Permissão para realizar chamadas',
          message: 'Este aplicativo precisa de acesso para realizar chamadas telefônicas.',
          buttonNeutral: 'Pergunte-me depois',
          buttonNegative: 'Cancelar',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        Linking.openURL('tel:123456789');
      } else {
        Alert.alert('Permissão negada', 'Não será possível realizar chamadas.');
      }
    } catch (err) {
      console.warn(err);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={makeCall}>
        <Text style={styles.buttonText}>Fazer Ligação</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, { backgroundColor: '#4CAF50', marginTop: 20 }]} onPress={() => navigation.navigate('SMS')}>
        <Text style={styles.buttonText}>Ir para SMS</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f2f2f2',
  },
  button: {
    backgroundColor: '#2196F3',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default PhoneScreen;
